package com.test.user.service.controllers;

import com.test.user.service.entities.Rating;
import com.test.user.service.entities.User;
import com.test.user.service.services.IUserService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    private final IUserService iUserService;

    public UserController(IUserService iUserService) {
        this.iUserService = iUserService;
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(iUserService.saveUser(user));
    }
    int retryCount  = 1;
    @GetMapping("/{userId}")
    @CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod = "ratingHotelFallback")
    //@Retry(name = "ratingHotelService" , fallbackMethod = "ratingHotelFallback")
    //@RateLimiter(name="userRateLimiter", fallbackMethod = "ratingHotelFallback")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId) {
        log.info("Retry count :: {} ",retryCount);
        retryCount++;
        return ResponseEntity.ok(iUserService.getUserByIdWithRatings(userId));
    }
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(iUserService.getAllUsers());
    }


    // rating fallback method for circuit breaker
    public ResponseEntity<User> ratingHotelFallback(String userId , Exception ex){
        log.info("Fallback is executed because rating service is down :: {}  ",ex.getMessage());
        /*User user = User.builder()
                .userId("123213")
                .email("dummy@gmail.com")
                .name("Dummy")
                .about("This is dummy is user because some service is down")
                .build();*/
        User user = iUserService.getUserById(userId);
        Rating rating = Rating.builder()
                .ratingId("123213")
                .stars(8)
                .userId("123213")
                .hotelId("222")
                .feedback("This feedback is dummy")
                .build();
        user.setRatings(List.of(rating));
        return new ResponseEntity<>(user,HttpStatus.OK);

    }
}
