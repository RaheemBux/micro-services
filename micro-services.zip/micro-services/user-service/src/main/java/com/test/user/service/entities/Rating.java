package com.test.user.service.entities;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Rating {
    private String ratingId;
    private String hotelId;
    private String userId;
    private Integer stars;
    private String feedback;
    private Hotel hotel;
}
