package com.test.user.service.services.impl;

import com.test.user.service.entities.Hotel;
import com.test.user.service.entities.Rating;
import com.test.user.service.entities.User;
import com.test.user.service.excpetions.ResourceNotFoundException;
import com.test.user.service.external.services.HotelService;
import com.test.user.service.external.services.RatingService;
import com.test.user.service.repositories.UserRepository;
import com.test.user.service.services.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserService implements IUserService {

    private final UserRepository userRepository;
    private final HotelService hotelService;
    private final RatingService ratingService;

    public UserService(UserRepository userRepository, HotelService hotelService, RatingService ratingService) {
        this.userRepository = userRepository;
        this.hotelService = hotelService;
        this.ratingService = ratingService;
    }

    @Override
    public User saveUser(User user) {
        user.setUserId(UUID.randomUUID().toString());
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserByIdWithRatings(String userId) {
        User user = userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("user not found on server with id : "+userId));
        // fetch rating details
        List<Rating> ratingsOfUser = ratingService.getRatingsByUserId(user.getUserId());
        log.info("ratings of user {} ",ratingsOfUser);

        List<Rating> ratingList = ratingsOfUser.stream().map(rating -> {
            // get hotel details
            Hotel hotel = hotelService.getHotel(rating.getHotelId());
            rating.setHotel(hotel);
            return rating;
        }).collect(Collectors.toList());

        user.setRatings(ratingList);
        return user;
    }

    @Override
    public User getUserById(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(()->new ResourceNotFoundException("user not found on server with id : "+userId));
    }
}
