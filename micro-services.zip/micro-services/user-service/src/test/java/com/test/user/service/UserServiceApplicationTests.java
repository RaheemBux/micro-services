package com.test.user.service;

import com.test.user.service.entities.Rating;
import com.test.user.service.external.services.RatingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceApplicationTests {

	@Autowired
	private RatingService ratingService;

	@Test
	void contextLoads() {
	}

	// just for testing feign client post method
	/*@Test
	void testCreateRating(){
		Rating rating = Rating.builder()
				.userId("a5987242-42c2-4ca2-b362-d0461eef6217")
				.hotelId("c2757607-7792-4ff8-a1c4-4b0742895a53")
				.stars(8)
				.feedback("This is good hotel")
				.build();
		Rating savedRating = ratingService.createRating(rating);
		System.out.println("Rating Created : "+savedRating.getRatingId());
	}*/

}
