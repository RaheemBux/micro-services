package com.test.hotel.service.controllers;

import com.test.hotel.service.entities.Hotel;
import com.test.hotel.service.services.IHotelService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotels")
@Slf4j
public class HotelController {

    private final IHotelService iHotelService;

    public HotelController(IHotelService iHotelService) {
        this.iHotelService = iHotelService;
    }

    @PostMapping
    public ResponseEntity<Hotel> createHotel(@RequestBody Hotel hotel) {
        return ResponseEntity.status(HttpStatus.CREATED).body(iHotelService.createHotel(hotel));
    }
    @GetMapping("{hotelId}")
    @CircuitBreaker(name = "hotelBreaker", fallbackMethod = "hotelFallback")
    public ResponseEntity<Hotel> getSingleHotel(@PathVariable String hotelId) {
        return ResponseEntity.status(HttpStatus.OK).body(iHotelService.getHotelById(hotelId));
    }
    @GetMapping
    public ResponseEntity<List<Hotel>> getAllHotels() {
        return ResponseEntity.ok(iHotelService.getAllHotels());
    }

    // rating fallback method for circuit breaker
    public ResponseEntity<Hotel> hotelFallback(Exception ex){
        log.info("Fallback is executed because hotel service is down :: {}  ",ex.getMessage());
        Hotel user = Hotel.builder()
                .id("222")
                .location("Karachi")
                .name("Test Hotel")
                .about("This is Test is Hotel because some service is down")
                .build();
        return new ResponseEntity<>(user,HttpStatus.OK);

    }
}
