package com.test.hotel.service.services;

import com.test.hotel.service.entities.Hotel;

import java.util.List;

public interface IHotelService {

    Hotel createHotel(Hotel hotel);
    List<Hotel> getAllHotels();
    Hotel getHotelById(String id);
}
