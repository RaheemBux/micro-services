package com.test.rating.service.entities;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Document("rating")
@Builder
public class Rating {
    @Id
    private String ratingId;
    private String hotelId;
    private String userId;
    private Integer stars;
    private String feedback;
}
