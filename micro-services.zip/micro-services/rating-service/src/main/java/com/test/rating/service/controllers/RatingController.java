package com.test.rating.service.controllers;

import com.test.rating.service.entities.Rating;
import com.test.rating.service.services.IRatingService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/ratings")
@Slf4j
public class RatingController {

    private final IRatingService iRatingService;

    public RatingController(IRatingService iRatingService) {
        this.iRatingService = iRatingService;
    }

    @PostMapping
    public ResponseEntity<Rating> createRating(@RequestBody Rating rating) {
        return ResponseEntity.status(HttpStatus.CREATED).body(iRatingService.createRating(rating));
    }
    @GetMapping
    public ResponseEntity<List<Rating>> getAllRatings() {
        return ResponseEntity.ok(iRatingService.getAllRatings());
    }

    @GetMapping("/users/{userId}")
    @CircuitBreaker(name = "ratingBreaker", fallbackMethod = "ratingFallback")
    public ResponseEntity<List<Rating>> getAllRatingsByUserId(@PathVariable String userId) throws Exception {
        return ResponseEntity.ok(iRatingService.getAllRatingsByUserId(userId));
    }

    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Rating>> getAllRatingsByHotelId(@PathVariable String hotelId) {
        return ResponseEntity.ok(iRatingService.getAllRatingsByHotelId(hotelId));
    }
    public ResponseEntity<List<Rating>> ratingFallback(Exception ex){
        log.info("Fallback is executed because rating service is down :: {}  ",ex.getMessage());

        Rating rating = Rating.builder()
                .ratingId("123213")
                .stars(8)
                .userId("123213")
                .hotelId("222")
                .feedback("This feedback is dummy")
                .build();

        return new ResponseEntity<>(List.of(rating),HttpStatus.OK);

    }
}
