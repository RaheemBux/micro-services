package com.test.rating.service.services;

import com.test.rating.service.entities.Rating;

import java.util.List;

public interface IRatingService {

    Rating createRating(Rating rating);
    List<Rating> getAllRatings();
    List<Rating> getAllRatingsByUserId(String userId) throws Exception;
    List<Rating> getAllRatingsByHotelId(String hotelId);
}
